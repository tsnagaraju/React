import { display } from './moduledemo'

import person from './moduledemo'

