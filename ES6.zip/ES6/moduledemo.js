class Person {
    // f1
    // f2
}

export default person;
