// create promise

let flag = false;

let myPromise = new Promise((resolve, reject) => {
    if (flag) {
        resolve('done...')
    } else {
        reject('something went wrong')
    }
})

// cosuming promise

// fetch('url')
//     .then((res) => console.log(res))
//     .catch((err) => console.error(err))

let asyncDemo = () => {
    return new Promise(resolve => {
        setTimeout(() => resolve('I am done...'), 3000)
    })
}

let doSomething = async () => {
    console.log(await asyncDemo())
}

console.log('before')
doSomething()
console.log('after')