let x = 9;
let message = 'firstline \n ' + 'lastline ${x}'

//alert(message)

let name = "nagaraju setti"

let msg = `hai ${name}
good evening and 
what are you doing`
//alert(msg)

let person = {
    name: 'nagaraju',
    city: 'hyderabad'
}

document.write(person.name + " " + person.city)
document.write(`<br> ${person.name} ${person.city}`)
