// let, const, var demo
// function print() {
//     var x = 5;
//     console.log(x)
//     flag = true;
//     if (flag) {
//         let isIt = "true"
//     }

//     const msg = 'hello'
//     const person = Object.freeze({ age: 10 })
//     alert(person.age)
//     person.age = 25
//     alert(person.age)
// }
// print()

// setTimeout(function () {
//     alert('hai, good afternoon')
// }, 3000)

// setTimeout(() => alert('hai, good evening'), 3000)

// var print = (a) => alert("a: " + a)

// var print = a => {
//     return this.a
// };

// alert(print(5))

// spread operator
// let msg = 'hai'
// let reply = [...msg]
// alert(reply)

let n1 = [1, 2, 3]
let n2 = [7, 8, 9]

//let nums = [...n1, 4, 5, 6, ...n2]
//alert(nums)

// rest parameter
function print(a, b, ...c) {
    alert("a: " + a + "b: " + b + "c: " + c)
}
//print(1, 2, 3, 4, 5, 6, 7, 9)

// spread operator can be anywhere in that but rest parameter can be last parameter
// we can have more than one spread operators but there must be only one rest
// rest parameter

let nums = [1, 2, 3, 4, 5, 6]
let [a, b, ...c] = nums;
alert(a + " " + b + " " + c)
// spred unpacks that elements where as rest parameter packs that elements

