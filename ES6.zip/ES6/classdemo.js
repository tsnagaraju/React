class Person {
    display() {
        alert('class Person: parent class')
    }
}

class Employee extends Person {
    constructor(name) {
        super()
        this.name = name;

    }
    print() {
        alert(this.name)
    }
    display() {
        super.display()
        alert('child Employe: child class')
    }
}

let e1 = new Employee('nagaraju')
// e1.print()
// e1.display()

class Demo {
    static sayHello() {
        alert('hello, good evening')
    }
}
Demo.sayHello()

