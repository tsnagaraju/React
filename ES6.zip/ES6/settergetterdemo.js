class Person {
    constructor(name) {
        this.name = name;
    }
    set personName(pname) {
        this.name = pname;
    }

    get personName() {
        return this.name;
    }
}
let p = new Person('nagaraju');
p.personName = "nagaraju setti"
document.write(p.personName)