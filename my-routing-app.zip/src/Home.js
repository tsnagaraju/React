import React, { Component } from 'react'
import { getAll } from './product.service';
import { Link } from 'react-router-dom'

class Home extends Component {
    constructor() {
        super()
        this.state = {
            products: []
        }
    }

    componentDidMount() {
        getAll()
            .then((res) => this.setState({ products: res.data }))
    }

    render() {
        document.title = "My Home"
        return (
            <div>
                <table className="table">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Price</th>
                    </tr>
                    {this.state.products.map((p) =>
                        <tr>
                            <td>{p.id}</td>
                            <td>{p.name}</td>
                            <td>{p.price}</td>
                            <td><Link to="/update" className="btn btn-info">Update</Link></td>
                            <td><button className="btn btn-danger">Delete</button></td>
                        </tr>
                    )}
                </table>
                <Link to="/add" className="btn btn-primary" >Add</Link>
            </div>
        )
    }
}


export default Home