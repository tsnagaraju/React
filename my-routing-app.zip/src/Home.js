import React, { Component } from 'react'
import { getAll, deleteProduct } from './product.services';
import { Link } from 'react-router-dom'

class Home extends Component {
    constructor() {
        super()
        this.state = {
            products: []
        }
    }
    componentDidMount() {
        getAll()
            .then((res) => this.setState({ products: res.data }))
    }
    remove = (pid) => {
        deleteProduct(pid)
            .then(() => {
                alert('deleted...')
                this.props.history.go()
            })
    }
    render() {
        return (
            <div>
                <table className="table">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Price</th>
                    </tr>
                    {this.state.products.map((p, i) =>
                        <tr>
                            <td>{p.id}</td>
                            <td>{p.name}</td>
                            <td>{p.price}</td>
                            <td><Link to={{ pathname: '/update', state: { product: p } }} className="btn btn-info">Update</Link></td>
                            <td><button onClick={() => this.remove(p.id)} className="btn btn-danger">Delete</button></td>
                        </tr>
                    )}
                </table>
                <Link to="/add" className="btn btn-primary">Add</Link>
            </div>
        )
    }
}

export default Home