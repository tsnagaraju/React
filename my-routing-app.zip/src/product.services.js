import axios from 'axios'

// fetch all products
export function getAll() {
    return axios.get("http://localhost:3000/products")
}

// add given object
export function addProduct(product) {
    return axios.post("http://localhost:3000/products", product)
}

// update product for a given id
export function updateProduct(product) {
    return axios.put("http://localhost:3000/products/" + product.id, product)
}

// delete product for given id
export function deleteProduct(id) {
    return axios.delete("http://localhost:3000/products/" + id)
}