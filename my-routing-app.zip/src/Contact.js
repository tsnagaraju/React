import React, { Component } from 'react'

class Contact extends Component {
    render() {
        document.title = "Contact US"
        return (
            <div>
                <h3>Contact {this.props.match.params.empName}</h3>
            </div>
        )
    }
}


export default Contact