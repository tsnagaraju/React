import React, { Component } from 'react'
import { updateProduct } from './product.services';

class Update extends Component {
    constructor() {
        super()
        this.state = {
            product: ''
        }
    }

    componentDidMount() {

        this.setState({ product: this.props.location.state.product })
    }

    update = () => {
        let product = { id: this.refs.id.value, name: this.refs.name.value, price: this.refs.price.value }

        updateProduct(product)
            .then(() => {
                alert('updated...')
                this.props.history.push('/')
            })
    }
    render() {
        return (
            <div>
                ID:
                <input type="text" ref="id" className="form-control" readOnly defaultValue={this.state.product.id} />
                Name:
                <input type="text" ref="name" className="form-control" defaultValue={this.state.product.name} />
                Price:
                <input type="text" ref="price" className="form-control" defaultValue={this.state.product.price} />
                <button className="btn btn-success" onClick={this.update}>Save</button>
            </div>
        )
    }
}

export default Update