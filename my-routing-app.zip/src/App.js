import React from 'react';
import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Route } from 'react-router-dom'
import Contact from './Contact';
import Home from './Home';
import About from './About';
import Update from './update';
import Add from './add';
function App() {
  return (
    <Router>
      <div>

        <main>
          <Route exact path="/" component={Home} />
          <Route path="/update" component={Update} />
          <Route path="/add" component={Add} />

        </main>
      </div>
    </Router>
  );
}

export default App;
