import React from 'react';

import './App.css';
import { BrowserRouter as Router, Route } from 'react-router-dom'
import Home from './Home';
import Update from './Update';
import Add from './Add';
function App() {
  return (
    <Router>
      <div>
        <Route exact path="/" component={Home} />
        <Route path="/update" component={Update} />
        <Route path="/add" component={Add} />
      </div>
    </Router>
  );
}

export default App;
