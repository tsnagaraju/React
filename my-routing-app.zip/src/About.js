import React, { Component } from 'react'

class About extends Component {
    render() {
        document.title = "About US"
        return (
            <div>
                <h3>About Component</h3>
            </div>
        )
    }
}


export default About