import React, { Component } from 'react'

class Update extends Component {
    render() {
        return (
            <div></div>
        )
    }
}

export default Update