import axios from 'axios'

export function getAll() {
    return axios.get(" http://localhost:3000/products")
}

export function addProduct(product) {
    return axios.post(" http://localhost:3000/products", product)
}

export function updateProduct(product) {
    return axios.put(" http://localhost:3000/products/" + product.id, product)
}

export function deleteProduct(id) {
    return axios.delete(" http://localhost:3000/products/" + id)
}