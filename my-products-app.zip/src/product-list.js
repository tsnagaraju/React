import React, { Component } from 'react'
import ProductDetails from './product-details';

class ProductList extends Component {

    constructor() {
        super()
        this.state = {
            products: [
                { id: 1, name: 'iphone 6s', price: 8999, imageUrl: 'images/iphone_6s.jpg', likes: 1 },
                { id: 2, name: 'mouse', price: 199, imageUrl: 'images/iphone_6s.jpg', likes: 1 },
                { id: 3, name: 'rice', price: 89, imageUrl: 'images/iphone_6s.jpg', likes: 1 },
                { id: 4, name: 'laptop', price: 12000, imageUrl: 'images/iphone_6s.jpg', likes: 1 }
            ]
        }
    }

    updateLikes = (pid) => {
        let products = this.state.products;
        products.forEach((p) => {
            if (p.id === pid) {
                p.likes += 1;
            }
        })
        this.setState({ products: products })
    }

    render() {
        return (
            <div>
                {this.state.products.map((product) =>
                    <ProductDetails
                        id={product.id}
                        name={product.name}
                        price={product.price}
                        imageUrl={product.imageUrl}
                        likes={product.likes}
                        increment={this.updateLikes}
                    />
                )}
            </div>
        )
    }
}

export default ProductList