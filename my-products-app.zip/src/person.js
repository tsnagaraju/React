import React, { Component } from 'react'

class Person extends Component {
    constructor() {
        super()
        this.state = {
            name: 'naga'
        }
        this.changeName = this.changeName.bind(this)
    }

    changeName() {
        this.setState({ name: 'nagaraju setti' })
    }

    changeCase = () => {
        let n = this.refs.name.value
        this.setState({ name: n.toUpperCase() })
    }
    render() {
        return (
            <div>
                {/* Name: {this.state.name}<br /><br />
                <button onClick={this.changeName}>Change</button> */}
                {this.state.name}<br />
                <input type="text" ref="name" onKeyUp={this.changeCase} />
            </div>
        )
    }
}

export default Person