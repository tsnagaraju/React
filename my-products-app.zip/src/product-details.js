// import React, { Component } from 'react'
import React from 'react'
import './product.css'

// class ProductDetails extends Component {
function ProductDetails(props) {
    // render() {
    return (
        <div className="main">
            <div className="image">
                <img src={props.imageUrl} />
            </div>
            <div className="content">
                <div>ID: {props.id}</div>
                <div>Name: {props.name}</div>
                <div>Price: {props.price}</div>
                <div><a href="#" onClick={
                    () => props.increment(props.id)
                }>Likes: {props.likes}</a></div>
            </div>

        </div>
    )
    //}
}

export default ProductDetails