import React, { Component } from 'react'

class HelloWorld extends Component {
    constructor(props) {
        super()
        this.state = {
            name: props.name,
            city: props.city
        }
    }
    init = () => {
        this.props.city = "Pune"
        this.setState({ name: 'nagaraju setti' })
    }
    render() {
        return (
            <div>
                <p>Name: {this.state.name}</p>
                <p>City: {this.state.city}</p>
                <button onClick={this.init}>Init</button>
            </div>
        )
    }
}

export default HelloWorld