import React from 'react';
import logo from './logo.svg';
import './App.css';
import HelloWorld from './HelloWorld';
import ProductList from './product-list';
import Person from './person';

function App() {
  return (
    <div >
      {/* <HelloWorld name="nagaraju" city="hyderabad" /> */}
      {/* <ProductList /> */}
      <Person />
    </div>
  );
}

export default App;
