import React from 'react';
import logo from './logo.svg';
import './App.css';
import ProductList from './product-list';

function App() {
  return (
    <div>
      <ProductList />
    </div>
  );
}

export default App;
