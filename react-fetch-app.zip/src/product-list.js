import React, { Component } from 'react'
import { getAllProducts, addProduct, updateProduct, deleteProduct } from './product.service';

class ProductList extends Component {
    constructor() {
        super()
        this.state = {
            products: []
        }
    }
    componentDidMount() {
        getAllProducts().then((res) => this.setState({
            products: res.data
        }))

    }
    add = () => {
        let p = { name: 'banana', price: 9 }
        addProduct(p)
            .then(() => {
                alert('added...')
                window.location.reload()
            })
    }

    update = () => {
        let p = { id: 3, name: 'mango', price: 12 }
        updateProduct(p)
            .then(() => alert('updated...'))
    }

    delete = () => {
        deleteProduct(5)
            .then(() => alert('removed...'))
    }
    render() {
        return (
            <div>
                <table border="1">
                    <tr>
                        <th>ID</th><th>Name</th><th>Price</th>
                    </tr>
                    {this.state.products.map((p, i) =>
                        <tr key={i}>
                            <td>{p.id}</td>
                            <td>{p.name}</td>
                            <td>{p.price}</td>
                        </tr>)}
                </table>
                <button onClick={this.add}>Add</button>
                <button onClick={this.update}>Update</button>
                <button onClick={this.delete}>Delete</button>
            </div>
        )
    }
}

export default ProductList