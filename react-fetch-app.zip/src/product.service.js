import axios from 'axios'

export function getAllProducts() {
    return axios.get('http://localhost:3000/products')
}

export function addProduct(p) {
    return axios.post('http://localhost:3000/products', p)
}

export function updateProduct(p) {
    return axios.put('http://localhost:3000/products/' + p.id, p);
}

export function deleteProduct(pid) {
    return axios.delete('http://localhost:3000/products/' + pid)
}