import React, { Component } from 'react'
import { connect } from 'react-redux';
import { Link } from 'react-router-dom'
class Home extends Component {
    render() {
        return (
            // <div>Home Component</div>
            <div>
                <table border="1">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.props.products.map((p) =>
                            <tr key={p.id}>
                                <td>{p.id}</td>
                                <td>{p.name}</td>
                                <td>{p.price}</td>

                            </tr>
                        )}
                    </tbody>
                </table>
                <Link to="/add">Add</Link>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        products: state.productreducer.products
    }
}

export default connect(mapStateToProps)(Home)