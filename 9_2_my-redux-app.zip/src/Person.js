import React, { Component } from 'react'

export const { Provider, Consumer } = React.createContext()

class Person extends Component {
    constructor() {
        super()
        this.state = {
            name: 'nagaraju setti'
        }
    }
    render() {
        return (
            <div>
                <Provider value={{ state: this.state }}>{this.props.children}</Provider>
            </div>
        )
    }
}

export default Person