import React, { Component } from 'react'

class Register extends Component {

    render() {
        return (
            <div>
                <h3>Register Component</h3>
            </div>
        )
    }
}


export default Register

