import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import { combineReducers, createStore } from 'redux';
import { Provider } from 'react-redux'

// initial state
let initialState = {
  products: [
    {
      id: 1, name: 'apple', price: 29
    }
  ]
}

//reducer 
let productreducer = (state = initialState, action) => {
  switch (action.type) {
    case 'READ':
      return state;
    case 'ADD':
      let products = state.products;
      products.push(action.value)
      state = {
        products: products
      }
      return state;
    case 'UPDATE':
      return state;
    case 'DELETE':
      return state;
    default:
      return state;
  }
}
let reducer = combineReducers({ productreducer })

// define store
const store = createStore(reducer)

console.log(store.getState())

ReactDOM.render(
  <Provider store={store}><App /></Provider>,
  document.getElementById('root')
);


