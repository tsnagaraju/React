import React, { Component } from 'react'
import { bindActionCreators } from 'C:/Users/nasetti/AppData/Local/Microsoft/TypeScript/3.3/node_modules/redux';
import { connect } from 'react-redux';

class Add extends Component {
    componentWillMount() {
        this.props.dispatch({ type: 'READ', value: '' })
    }
    add = () => {
        let product = { id: 2, name: 'rice', price: 60 }
        this.props.dispatch({ type: 'ADD', value: product })
        this.props.history.push("/")
    }
    render() {
        return (
            <div>
                <button onClick={this.add}>Add</button>
            </div>
        )
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        actions: bindActionCreators(dispatch)
    }
}
export default connect(mapDispatchToProps)(Add)