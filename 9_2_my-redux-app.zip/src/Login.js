import React, { Component } from 'react'
import Home from './Home';
import Register from './Register';

class Login extends Component {
    constructor() {
        super()
        this.state = {
            name: 'nagaraju',
            pass: 'setti'
        }
    }
    render() {
        if (this.state.name == "nagaraju" && this.state.pass == "setti") {
            const LoginCheck = withCondition(Home)
            return (<div><LoginCheck /></div>)
        } else {
            const LoginCheck = withCondition(Register)
            return (<div><LoginCheck /></div>)
        }
    }
}


export default Login

const withCondition = (Component) => () => <Component />

