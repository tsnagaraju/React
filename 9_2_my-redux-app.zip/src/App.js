import React, { Suspense } from 'react';
import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Route } from 'react-router-dom'
import Login from './Login';
import Person from './Person';
import Employee from './Employee';

const Home = React.lazy(() => import('./Home'))
const Add = React.lazy(() => import("./Add"))

function App() {
  return (
    // <Login />
    // <Person>
    //   <Employee />
    // </Person>
    <Suspense fallback={<p>Please wait</p>}>
      <Router>
        <div>
          <Route exact path="/" component={Home} />
          <Route path="/add" component={Add} />
        </div>
      </Router>
    </Suspense>

  );
}

export default App;
