import React, { Component } from 'react'
import { Consumer } from './Person';

class Employee extends Component {
    render() {
        return (
            <div>
                <Consumer>
                    {
                        (context) => <p>Name: {context.state.name}</p>
                    }
                </Consumer>
            </div>
        )
    }
}

export default Employee