import React from 'react';
import logo from './logo.svg';
import './App.css';
import UserLoginForm from './UserLoginForm';
import UserRegisterForm from './UserRegisterForm';

function App() {
  return (
    <div >
      {/* <UserLoginForm /> */}
      <UserRegisterForm />
    </div>
  );
}

export default App;
