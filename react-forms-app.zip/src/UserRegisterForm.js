import React, { Component } from 'react'
import { Form, Input, Label, FormGroup, Row, Col, Button, FormFeedback } from 'reactstrap'
import './register.css'

class UserRegisterForm extends Component {
    constructor() {
        super()
        this.state = {
            user: '',
            pass: '',
            cb: false
        }
    }
    handleUser = (event) => {
        this.setState({ user: event.target.value })
    }
    handlePassword = (event) => {
        this.setState({ pass: event.target.value })
    }
    handleCheckbox = (event) => {
        this.setState({ cb: event.target.checked })
    }
    render() {
        return (
            <div>
                <Form>
                    <Row>
                        <Col>
                            <FormGroup>
                                <Label>Username:</Label>
                                <Input type="text" valid={this.state.user.length >= 5} invalid={this.state.user.length < 5} onChange={this.handleUser} />
                                <FormFeedback invalid>
                                    {this.state.user.length < 5 && this.state.user.length >= 1 ? "user field length is 5 chars long" : ''}
                                </FormFeedback>
                            </FormGroup>
                        </Col>
                        <Col>
                            <FormGroup>
                                <Label>Password:</Label>
                                <Input type="password" onChange={this.handlePassword} valid={this.state.pass.length >= 5} invalid={this.state.pass.length < 5} onChange={this.handlePassword} />
                                <FormFeedback invalid>
                                    {this.state.pass.length < 5 && this.state.pass.length >= 1 ? "password field length is 5 chars long" : ''}
                                </FormFeedback>
                            </FormGroup>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <FormGroup check inline>
                                <Label>
                                    <Input type="checkbox" onChange={this.handleCheckbox} />Accept T & C
                                   <br /><small className="text-danger"> {this.state.cb ? '' : 'please accept t & c'}</small>
                                </Label>
                            </FormGroup>

                        </Col>
                    </Row>
                    <Button color="primary"
                        disabled={!(this.state.user.length >= 5 && this.state.pass.length >= 5 && this.state.cb)}>Submit</Button>
                </Form>
            </div>
        )
    }
}

export default UserRegisterForm