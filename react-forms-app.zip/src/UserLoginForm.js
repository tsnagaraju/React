import React, { Component } from 'react'

class UserLoginForm extends Component {
    constructor() {
        super()
        this.state = {
            user: '',
            pass: ''
        }

    }
    // handleUsername = (event) => {
    //     this.setState({ user: event.target.value })
    // }
    handleUsername = () => {
        this.setState({ user: this.username.value })
    }
    // handlePassword = (event) => {
    //     this.setState({ pass: event.target.value })
    // }
    handlePassword = () => {
        this.setState({ pass: this.password.value })
    }
    handleSubmit = () => {
        alert("username: " + this.state.user + ", password: " + this.state.pass)
    }
    render() {
        return (
            <div>
                <form onSubmit={this.handleSubmit}>
                    Username:
                    <input type="text" ref={(ele) => this.username = ele} onChange={this.handleUsername} /><br />
                    Password:
                    <input type="password" ref={(ele) => this.password = ele} onChange={this.handlePassword} /><br />
                    <button>Submit</button>
                </form>
            </div>
        )
    }
}

export default UserLoginForm