import { sum, sub, mul, div } from './math'

test('testing sum', () => {
    expect(sum(3, 4)).toBe(7)
})

test('testing sub', () => {
    expect(sub(4, 3)).toBe(1)
})

test('testing mul', () => {
    expect(mul(3, 4)).toBe(12)
})

test('testing div', () => {
    expect(div(1, 1)).toBe(1)
})