import React from 'react';

import './App.css';
import { BrowserRouter as Router, Route } from 'react-router-dom'
// import Home from './Home';
// import Update from './Update';
// import Add from './Add';
const Home = React.lazy(() => import('./Home'))
const Add = React.lazy(() => import('./Add'))
const Update = React.lazy(() => import('./Update'))
function App() {
  return (
    <React.Suspense fallback={() => <p>loading...</p>}>
      <Router>
        <div>
          <Route exact path="/" component={Home} />
          <Route path="/update" component={Update} />
          <Route path="/add" component={Add} />
        </div>
      </Router>
    </React.Suspense>
  );
}

export default App;
