import React, { Component } from 'react'
import { addProduct } from './product.services';

class Add extends Component {
    add = () => {
        let p = { name: this.refs.name.value, price: this.refs.price.value }
        addProduct(p)
            .then(() => {
                alert('added...')
                this.props.history.push("/")
            })
    }
    render() {
        return (
            <div>
                Name:
                <input type="text" ref="name" className="form-control" />
                Price:
                <input type="text" ref="price" className="form-control" />
                <button className="btn btn-success" onClick={this.add}>Add</button>
            </div>
        )
    }
}

export default Add