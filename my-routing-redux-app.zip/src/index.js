import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import 'bootstrap/dist/css/bootstrap.min.css'
import { combineReducers, createStore } from 'redux';
import { Provider } from 'react-redux'

// initial state of our app
let initialState = {
  products: []
}

// define reducer
let productsreducer = (state = initialState, action) => {

  switch (action.type) {
    case 'show':
      state = {
        products: action.products
      }
      return state;
    case 'add':
      // dosomething
      return state;
    case 'update':
      // do something
      return state;
    case 'delete':
      //dosomething
      return state;
    default:
      return state;
  }
}

let reducer = combineReducers({ productsreducer })

// create store 

export const store = createStore(reducer)

// access state from store
console.log(store.getState())


ReactDOM.render(
  <React.StrictMode>
    <Provider store={store}><App /></Provider>
  </React.StrictMode>,
  document.getElementById('root')
);


