import React from 'react';
import logo from './logo.svg';
import './App.css';
import HelloWorld from './demo';
import Employee from './employee';
import { Home } from './home';

function App() {
  let person = { name: 'nagaraju', city: 'hyderabad' }
  return (
    <div>
      {/* <h1>React App</h1>
      <p>Hai, good afternoon</p>
      <HelloWorld name={person.name} city={person.city} />
      <HelloWorld {...person} /> */}
      {/* <Employee /> */}
      <Home />
    </div>
  );
}

export default App;
