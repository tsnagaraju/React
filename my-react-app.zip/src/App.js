import React from 'react';
import logo from './logo.svg';
import './App.css';
import HelloWorld from './demo';
import Employee from './employee';
import { Home } from './home';
import Products, { MyApp } from './products';
import TodoList from './todolist';
import Calculate from './calculate_price';
import Person from './person';
import Customer from './customer';

function App() {
  let person = { name: 'sravan', city: 'hyderabad', id: 1 }

  return (
    <div>
      {/* <h1>React App</h1>
      <p>Hai, good afternoon</p>
      <HelloWorld name={person.name} city={person.city} />
      <HelloWorld {...person} /> */}
      {/* <Employee /> */}
      {/* <Products /> */}
      {/* <TodoList /> */}
      {/* <Calculate /> */}
      {/* <Person personName={person.name} personCity={person.city} /> */}
      <Person name={person.name} city={person.city} id={person.id} >
        Hello what are you doing
      </Person>
      {/* <Customer cname={10} /> */}

    </div>
  );
}

export default App;


