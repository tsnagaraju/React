import React, { Component } from 'react'

class TodoList extends Component {
    constructor() {
        super()
        this.state = {
            tasks: [],

        }
    }
    addTask = () => {
        let tasks = this.state.tasks;
        tasks.push(this.refs.task.value)
        this.setState({ tasks: tasks })
    }
    removeTask = (ind) => {
        let tasks = this.state.tasks;
        tasks.splice(ind, 1);
        this.setState({ tasks: tasks })
    }
    render() {
        return (
            <div>
                <input type="text" id="task" name="task" ref="task" />
                <button onClick={this.addTask}>Add Task</button>
                <ul>
                    {this.state.tasks.map((t, a) =>
                        <li key={a}>
                            {t}<button onClick={() => this.removeTask(a)}>Remove</button>
                        </li>
                    )}
                </ul>
            </div>
        )
    }
}

export default TodoList