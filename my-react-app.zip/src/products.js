import React, { Component } from 'react'

class Products extends Component {
    constructor() {
        super()
        this.state = {
            username: 'nagaraju setti',
            city: 'hyderabad',
            skills: ['java', 'pega', 'react', 'node', 'angular']
        }
    }

    changeState = () => {
        setTimeout(() => {
            this.setState({ username: 'Medapati, Sravan' })
        }, 3000)
    }

    render() {
        return (
            <div>
                <h1>Product Component</h1>
                <p>Username: {this.state.username}</p>
                <p>City: {this.state.city}</p>
                <button onClick={this.changeState}>Change Username</button>
                <p>
                    <ul>
                        {this.state.skills.map((s, a) =>
                            <li key={a}>{s}</li>)}
                    </ul>
                </p>
            </div>
        )
    }
}

export default Products



