import React, { Component } from 'react'
import './demo.css'

class HelloWorld extends Component {
    render() {
        let name = "nagaraju"
        let style = { backgroundColor: "blue", color: 'white' }

        return (
            <div className="box">
                {/* {{ 'nagaraju setti'}}<br /> */}
                Hello, Mr.{name}
                <div>{'\u00A9 2020'}</div>
                <p style={style}>this is paragraph</p>
            </div>
        )
    }
}



export default HelloWorld