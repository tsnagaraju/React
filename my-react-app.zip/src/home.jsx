import React, { Component } from 'react'

export class Home extends Component {
    name = "nagaraju setti"
    display() {
        alert('this is display')
    }
    doSum(a, b) {
        alert("sum: " + (a + b))
    }
    render() {
        return (
            <div>
                <h1>Home Component</h1>
                {this.name}
                <button onClick={this.display}>Click</button>
                <button onClick={() => this.doSum(5, 4)}>Sum</button>
            </div>
        )
    }
}