import React, { Component } from 'react'

class Calculate extends Component {
    constructor() {
        super()
        this.state = {
            totalPrice: 0
        }
    }

    calculatePrice = () => {
        let t = this.refs.tickets.value;
        this.setState({ totalPrice: t * 150 })
    }
    render() {
        return (
            <div>

                <input type="number" ref="tickets" min="1" max="10" />
                <p>Total Price: {this.state.totalPrice}</p>
                <button onClick={this.calculatePrice}>Calculate</button>
            </div>
        )
    }
}

export default Calculate;