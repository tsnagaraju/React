import React from 'react'

const Customer = (props) => {
    return (
        <div>
            Customer Name:  {props.cname}
        </div>
    )
}

export default Customer