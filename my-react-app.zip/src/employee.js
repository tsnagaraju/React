import React, { Component } from 'react'

class Employee extends Component {
    render() {
        let skills = ['java', 'pega', 'react']
        let products = [
            { id: 1, name: 'mouse', price: 199 },
            { id: 2, name: 'headphones', price: 99 },
            { id: 3, name: 'iphone 6s', price: 9999 }
        ]
        return (
            <div>
                <h3>Generating List:</h3>
                <ul>
                    {skills.map((s, a) =>
                        <li key={a}>{s}</li>
                    )}
                </ul>
                <h3>Generating Dropdown: </h3>
                <select>
                    {skills.map((s, a) =>
                        <option key={a}>{s}</option>
                    )}
                </select>
                <h3>Generating Table:</h3>
                <table border="1">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Price</th>
                    </tr>
                    {products.map((p, i) =>
                        <tr>
                            <td>{p.id}</td>
                            <td>{p.name}</td>
                            <td>{p.price}</td>
                        </tr>
                    )}
                </table>
            </div>
        )
    }
}

export default Employee;

