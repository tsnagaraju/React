import React, { Component } from 'react'
import PropTypes from 'prop-types'

class Person extends Component {
    render() {

        return (
            <div>
                <p>Name: {this.props.name}</p>
                <p>City: {this.props.city}</p>
                <p>ID: {this.props.id}</p>
                <p>{this.props.children}</p>
            </div>
        )
    }
}

export default Person
Person.defaultProps = {
    name: 'nagaraju'
}
Person.propTypes = {
    name: PropTypes.string.isRequired,
    city: PropTypes.string,
    id: PropTypes.number.isRequired
}